use std::time::{SystemTime, UNIX_EPOCH};

use openmls::{key_packages::KeyPackageIn, prelude::ProtocolVersion};
use openmls_rust_crypto::RustCrypto;
use openmls_wasm::{Identity, Provider};
use tls_codec::Deserialize;

const EXPECTED_TTL_SECS: u64 = 605_400;

fn now_secs() -> Result<u64, String> {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| duration.as_secs())
        .map_err(|error| format!("clock error: {error}"))
}

#[test]
fn generated_key_packages_have_signed_short_lifetime() -> Result<(), String> {
    let provider = Provider::new();
    let identity = Identity::new(&provider, "ttl-rehearsal")
        .map_err(|error| format!("identity error: {error:?}"))?;
    let before = now_secs()?;
    let packages = identity.key_packages(&provider, 2);
    let after = now_secs()?;

    if packages.len() != 2 {
        return Err(format!("expected two packages, got {}", packages.len()));
    }

    for package in packages {
        let bytes = package.to_bytes();
        let decoded = KeyPackageIn::tls_deserialize(&mut bytes.as_slice())
            .map_err(|error| format!("decode error: {error:?}"))?;
        let validated = decoded
            .validate(&RustCrypto::default(), ProtocolVersion::Mls10)
            .map_err(|error| format!("signature/lifetime validation error: {error:?}"))?;
        let not_after = validated.life_time().not_after();
        if not_after < before + EXPECTED_TTL_SECS
            || not_after > after + EXPECTED_TTL_SECS
        {
            return Err(format!(
                "wrong signed lifetime: not_after={not_after}, expected creation time + {EXPECTED_TTL_SECS}"
            ));
        }
    }

    Ok(())
}

