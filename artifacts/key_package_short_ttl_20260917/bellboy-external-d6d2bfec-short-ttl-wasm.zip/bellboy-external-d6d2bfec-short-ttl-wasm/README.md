# bellboy-external-d6d2bfec-short-ttl-wasm

Test-only OpenMLS WASM for bellboy-external at d6d2bfec9f296914a6c11e7425568ab5e6bb7fe1.
Matching UHM checkout: uhm-chat-external at a5dd3f096c5fadff90cd7460d83def0431fcd760.
OpenMLS source: ce0ed8fde928db16f1c4709c30d18f2aaa4507c2.

Fresh KeyPackages are signed with not_after = generation time + 605400 seconds
(7 days + 10 minutes). Current Bellboy's 604800-second safety threshold leaves
about 10 minutes, minus upload/network delay. The two old Bellboy commits do
not implement signed-expiry FEFO or only_near_expiry. To observe that outcome,
use a reviewed forward-only upgrade to a Bellboy version with that feature.
Already uploaded KeyPackages keep their original signed lifetime.

Verification: SHA-256 values are in manifest.json. Run node verify.mjs after
unzip to check every file and generate one KeyPackage with the WASM. The signed
lifetime was checked by source/short_ttl.rs against the OpenMLS parser and
signature validator: cargo test -p openmls-wasm --test short_ttl --offline
(1 passed, 0 failed, 0 ignored). source/ttl.patch and source/Cargo.lock
reproduce the build change and dependency selection.

External UHM integration, current checkout only:
1. Run yarn install --frozen-lockfile; verify both Ermis packages installed
   at 2.1.0-external.4. The local node_modules observed during packaging was .2.
2. Copy pkg/openmls_wasm_bg.wasm only to
   uhm-chat-external/public/openmls_wasm_bg.wasm.
3. Keep JS glue inside the installed SDK bundle. Do not copy the generated
   JS or declarations into external UHM public.
4. Run yarn build and record this ZIP's manifest with the app build.
   The app README's published hash describes the normal artifact, not this
   temporary test override.

This external WASM has the same 118 exports and 41 imports by name/kind as
the normal artifact. Generated JS after SDK logger adaptation and declarations
were byte-identical to external.4 source. No JOIN/historical/PIN/archive patch
was included.

Use isolated DB/Datastore namespaces, accounts, devices and fresh browser
provider storage for the two baselines. Stop the old server writer and keep a
restore-tested snapshot before each forward-only migration hop. Never run an
old binary against a database already migrated to a newer schema. These ZIPs
contain client artifacts only. The server and UHM browser acceptance remain
unverified until exercised on the isolated dev server.
