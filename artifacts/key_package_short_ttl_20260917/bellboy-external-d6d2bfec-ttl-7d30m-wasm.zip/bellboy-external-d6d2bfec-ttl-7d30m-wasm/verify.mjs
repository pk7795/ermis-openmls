import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(readFileSync(join(root, 'manifest.json'), 'utf8'));
for (const [name, expected] of Object.entries(manifest.sha256)) {
  const actual = createHash('sha256').update(readFileSync(join(root, name))).digest('hex');
  if (actual !== expected) throw new Error('SHA-256 mismatch: ' + name);
}
const wasm = await import(join(root, 'pkg/openmls_wasm.js'));
await wasm.default({ module_or_path: readFileSync(join(root, 'pkg/openmls_wasm_bg.wasm')) });
const provider = new wasm.Provider();
const identity = new wasm.Identity(provider, 'zip-verification');
const bytes = identity.key_package(provider).to_bytes();
if (bytes.length < 100) throw new Error('KeyPackage generation failed');
console.log(JSON.stringify({ archive: manifest.archive_id, sha256: 'pass', wasm_runtime: 'pass', key_package_bytes: bytes.length }));
